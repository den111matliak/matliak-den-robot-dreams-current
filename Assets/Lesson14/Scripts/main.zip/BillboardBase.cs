using UnityEngine;

namespace Lesson14
{
    public abstract class BillboardBase : MonoBehaviour
    {
        public abstract void SetCamera(Camera camera);
    }
}